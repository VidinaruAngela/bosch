package aut.utcluj.isp.ex3;

/**
 * @author stefan
 */
public class Product {
    private String id;
    private String name;
    private Double price;

    public Product(String id, String name, Double price) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Double getPrice() {
        return price;
    }
}
