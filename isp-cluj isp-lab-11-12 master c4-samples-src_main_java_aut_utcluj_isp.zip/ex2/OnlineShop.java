package aut.utcluj.isp.ex2;

/**
 * @author stefan
 */
public class OnlineShop {
    private String webAddress;

    public OnlineShop(String name, String city, String webAddress) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String getWebAddress() {
        return webAddress;
    }
}
